//
// Name:    Joshua Kuiros
// Section: CMPSC 475
// Program: Assignment 4
// Date: September 26, 2013
//

#import <UIKit/UIKit.h>

@interface jjkAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
