//
//  jjkAppDelegate.h
//  Pentominoes
//
//  Created by Joshua Kuiros on 9/10/13.
//  Copyright (c) 2013 Joshua Kuiros. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jjkAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
