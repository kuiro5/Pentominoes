//
// Name:    Joshua Kuiros
// Section: CMPSC 475
// Program: Assignment 3
// Date: September 19, 2013
//

#import <UIKit/UIKit.h>

@interface jjkViewController : UIViewController

@end
